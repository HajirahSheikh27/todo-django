from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Task(models.Model):
    #because primary key in pjango is by defalt and wo id hote hai islie foriegn key abanya hai because i maybe a user has 20 tasks uske lie you
    #have to link all those tasks to the user
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField(null=True, blank=True)
    completed = models.BooleanField(default=False)
    
    category = models.CharField(max_length=100, blank=True)
    tags = models.CharField(max_length=200, blank=True)  # Comma-separated tags
    recurrence = models.CharField(
        max_length=50,
        choices=[
            ('none', 'None'),
            ('daily', 'Daily'),
            ('weekly', 'Weekly'),
            ('monthly', 'Monthly')
        ],
        default='none'
    )
    priority = models.CharField(
        max_length=10,
        choices=[
            ('low', 'Low'),
            ('medium', 'Medium'),
            ('high', 'High')
        ],
        default='medium'
    )
    #pata hai how a task is represented as a string, when you print a task it shows the title
    def __str__(self):
        return self.title
    #adds jitne bhi days to the due date
    def schedule_next_task(self):
        if self.recurrence == 'daily':
            self.due_date += timezone.timedelta(days=1)
        elif self.recurrence == 'weekly':
            self.due_date += timezone.timedelta(weeks=1)
        elif self.recurrence == 'monthly':
            self.due_date += timezone.timedelta(days=30)  

