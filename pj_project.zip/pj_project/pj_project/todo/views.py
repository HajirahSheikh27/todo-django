from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Task
from .forms import TaskForm

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

from .forms import CustomUserCreationForm
from django.contrib.auth import logout


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        #agr user valid hai tou it saves the new user to the database, logins in automatically and profile page pe chala jata hai
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('profile')
    else:
        form = CustomUserCreationForm()
    # return render(request, 'register.html', {'form': form})
        return render(request, 'registration/register.html', {'form': form})



@login_required
def profile(request):
    return render(request, 'registration/profile.html')


@login_required
def task_list(request):
    #it filters all the tasks of the logged in user
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'todo/task_list.html', {'tasks': tasks})

@login_required
def task_detail(request, pk):
    task = get_object_or_404(Task, pk=pk)
    return render(request, 'todo/task_detail.html', {'task': task})

@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'todo/task_form.html', {'form': form})

@login_required
def task_update(request, pk):
    task = Task.objects.get(pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        #it shows the form with the presxisting form data
        form = TaskForm(instance=task)
    return render(request, 'todo/task_form.html', {'form': form})


@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        task.delete()
        return redirect('task_list')
    return render(request, 'todo/task_confirm_delete.html', {'task': task})




def custom_logout(request):
    logout(request)
    return redirect('logout_page')

def logout_page(request):
    return render(request, 'registration/logout_page.html')